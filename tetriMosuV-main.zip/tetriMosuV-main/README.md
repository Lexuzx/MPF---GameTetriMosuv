# tetriMosuV

3D-Tetris x osu! game built with React & Three.js

🎮 **Play Now:** [https://marvelcollin.github.io/tetriMosuV/](https://marvelcollin.github.io/tetriMosuV/)

## Screenshots

![image](https://github.com/user-attachments/assets/68355758-e442-480d-acc1-f72d04bdc3ee)
![image](https://github.com/user-attachments/assets/61c5e853-f1d3-4231-a518-c9d3bf479efd)
![image](https://github.com/user-attachments/assets/c83564db-7885-42bb-a521-5dce2da00689)
![image](https://github.com/user-attachments/assets/ed07396b-8c20-4b7c-aacd-d031429f3de7)
![image](https://github.com/user-attachments/assets/01843f80-ffb5-43b6-9899-d5f1a3da610d)
![gameplaybbangg](https://github.com/user-attachments/assets/905a3d65-1a91-4da0-8dd2-340fae27b9be)


