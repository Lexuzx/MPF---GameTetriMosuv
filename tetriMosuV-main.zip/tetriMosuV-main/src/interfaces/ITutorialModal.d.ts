export interface ITutorialModal {
  onClose: () => void;
}
