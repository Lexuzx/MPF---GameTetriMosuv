export interface ISettingModal {
  onClose: () => void;
  onRestart: () => void;
}