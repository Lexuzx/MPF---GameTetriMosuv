interface ICircle {
    backgroundColor: string;
}

export default ICircle;