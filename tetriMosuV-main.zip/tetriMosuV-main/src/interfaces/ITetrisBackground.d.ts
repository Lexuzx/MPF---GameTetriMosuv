export interface ITetrisBackground {
  selectedTheme: string;
}
