export interface IPreviewTetris {
  theme: string;
}
