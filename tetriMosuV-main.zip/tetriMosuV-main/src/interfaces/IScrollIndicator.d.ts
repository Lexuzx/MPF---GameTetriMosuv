export interface IScrollIndicator {
  text?: string;
  onClick?: () => void;
}
