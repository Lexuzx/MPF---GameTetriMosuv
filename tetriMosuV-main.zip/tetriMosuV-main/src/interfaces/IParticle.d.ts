export interface IParticle {
  x: number;
  y: number;
  speedX: number;
  speedY: number;
  size: number;
  color: string;
}
