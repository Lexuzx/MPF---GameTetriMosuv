export interface IGameOverModal {
    score: number;
    onClose: () => void;
}